const html=() =>{
 alert("Thank you Enrolling HTML, CSS, JS")
}

const app =() =>{
 alert("Thank you Enrolling Application Development")
}

const ml =() =>{
 alert("Thank you Enrolling Machine Learning")
}